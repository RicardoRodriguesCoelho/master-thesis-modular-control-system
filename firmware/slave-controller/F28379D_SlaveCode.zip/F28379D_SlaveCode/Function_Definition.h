/*
 * Function_Definition.h
 *
 *  Created on: 26/05/2022
 *      Author: Ricardo Coelho
 */

#ifndef FUNCTION_DEFINITION_H_
#define FUNCTION_DEFINITION_H_
#include "F28x_Project.h"

void slave_counter(Uint16 array[], Uint16 last_index);
Uint16 slave_config(Uint16 array[], Uint16 last_index, Uint16 total_slaves);
void slave_dc_bus(Uint16 array[], Uint16 last_index, Uint16 total_slaves);
Uint16 receive_pwm_data(Uint32 data);
void setup_pwm_phase(Uint16 phase_delay, Uint16 total_slaves);
void update_pwm(Uint16 counter_compare);
void start_pwm(void);
void stop_pwm(void);
Uint16 error_check(void);
void stop(void);

#endif /* FUNCTION_DEFINITION_H_ */
