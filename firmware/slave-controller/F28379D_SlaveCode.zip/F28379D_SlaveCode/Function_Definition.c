/*
 * Function_Definition.c
 *
 *  Created on: 26/05/2022
 *      Author: Ricardo Coelho
 */


//****************************************
// Includes
//****************************************
#include "Function_Definition.h"
#include "math.h"

//****************************************
// Defines
//****************************************
#define DC_Bus 60

//*************************************************************************************************************************
//*************************************************************************************************************************
void slave_counter(Uint16 array[], Uint16 last_index){
    int16 index = 0;

    if(last_index == 2){
        array[2] = 1;
        array[3] = 0x0024;
    }
    else{
        array[last_index] = array[last_index-1] + 1;
        array[last_index+1] = 0x0024;
    }

    while (index < last_index+2){
        SpiaRegs.SPITXBUF = array[index];
        index++;
        //DELAY_US(1000);
    }
}

//*************************************************************************************************************************
//*************************************************************************************************************************
Uint16 slave_config(Uint16 array[], Uint16 last_index, Uint16 total_slaves){
    int16 index = 0;
    Uint16 phase_delay;

    phase_delay = array[last_index];

    while (index < total_slaves + 3){
        SpiaRegs.SPITXBUF = array[index];
        index++;
    }

    return phase_delay;
}

//*************************************************************************************************************************
//*************************************************************************************************************************
void slave_dc_bus(Uint16 array[], Uint16 last_index, Uint16 total_slaves){
    int16 index = 0;

    array[last_index] = DC_Bus;

    while (index < total_slaves + 3){
        SpiaRegs.SPITXBUF = array[index];
        index++;
        //DELAY_US(1000);
    }
}

//*************************************************************************************************************************
//*************************************************************************************************************************
Uint16 receive_pwm_data(Uint32 data){
    Uint32  first_aux, second_aux, third_aux;

    data = GpioDataRegs.GPADAT.all;

    first_aux = ((data>>4) & 0x000000FF);
    second_aux = ((data>>16) & 0x00000F00);
    third_aux = first_aux | second_aux;

    third_aux = third_aux<<1;

    return ((Uint16)third_aux);
}

//*************************************************************************************************************************
//*************************************************************************************************************************
void setup_pwm_phase(Uint16 phase_delay, Uint16 total_slaves){
    static float32 phase_delay1, phase_delay2;
    Uint32 aux;

    phase_delay1 = phase_delay;
    phase_delay2 = phase_delay + (180.0 / total_slaves);

    if( phase_delay1 <= 180 ){
        EPwm1Regs.TBCTL.bit.PHSDIR = 0;
        EPwm8Regs.TBCTL.bit.PHSDIR = 0;
        aux = (phase_delay1 * 500 / 18);
        EPwm1Regs.TBPHS.bit.TBPHS = (Uint16)aux;
        EPwm8Regs.TBPHS.bit.TBPHS = (Uint16)aux;
    }
    else{
        EPwm1Regs.TBCTL.bit.PHSDIR = 1;
        EPwm8Regs.TBCTL.bit.PHSDIR = 1;
        aux = ((360 - phase_delay1) * 500 / 18);
        EPwm1Regs.TBPHS.bit.TBPHS = (Uint16)aux;
        EPwm8Regs.TBPHS.bit.TBPHS = (Uint16)aux;
    }

    if(phase_delay2 <= 180){
            EPwm2Regs.TBCTL.bit.PHSDIR = 0;
        aux = (phase_delay2 * 500 / 18);
        EPwm2Regs.TBPHS.bit.TBPHS = (Uint16)aux;
        //EPwm2Regs.TBPHS.bit.TBPHS = 5000;
    }
    else{
        EPwm2Regs.TBCTL.bit.PHSDIR = 1;
        aux = ((360 - phase_delay2) * 500 / 18);
        EPwm2Regs.TBPHS.bit.TBPHS = (Uint16)aux;
    }

}

//*************************************************************************************************************************
//*************************************************************************************************************************
void update_pwm(Uint16 counter_compare){
    EPwm1Regs.CMPA.bit.CMPA = counter_compare;
    EPwm8Regs.CMPA.bit.CMPA = counter_compare;
    EPwm2Regs.CMPA.bit.CMPA = counter_compare;

}

//*************************************************************************************************************************
//*************************************************************************************************************************
void start_pwm(void){
    EPwm1Regs.DBCTL.bit.POLSEL = DB_ACTV_HIC;
    EPwm1Regs.AQCSFRC.bit.CSFA = 0;                 // Forces a continuous low on output A
    EPwm1Regs.AQCSFRC.bit.CSFB = 0;                 // Forces a continuous low on output B
    EPwm8Regs.DBCTL.bit.POLSEL = DB_ACTV_HIC;
    EPwm8Regs.AQCSFRC.bit.CSFA = 0;                 // Forces a continuous low on output A
    EPwm8Regs.AQCSFRC.bit.CSFB = 0;                 // Forces a continuous low on output B


    EPwm2Regs.DBCTL.bit.POLSEL = DB_ACTV_HIC;
    EPwm2Regs.AQCSFRC.bit.CSFA = 0;                 // Forces a continuous low on output A
    EPwm2Regs.AQCSFRC.bit.CSFB = 0;                 // Forces a continuous low on output B
}

//*************************************************************************************************************************
//*************************************************************************************************************************
void stop_pwm(void){
    EPwm1Regs.DBCTL.bit.POLSEL = DB_ACTV_HI;
    EPwm1Regs.AQCSFRC.bit.CSFA = 1;                 // Forces a continuous low on output A
    EPwm1Regs.AQCSFRC.bit.CSFB = 1;                 // Forces a continuous low on output B
    EPwm8Regs.DBCTL.bit.POLSEL = DB_ACTV_HI;
    EPwm8Regs.AQCSFRC.bit.CSFA = 1;                 // Forces a continuous low on output A
    EPwm8Regs.AQCSFRC.bit.CSFB = 1;                 // Forces a continuous low on output B

    EPwm2Regs.DBCTL.bit.POLSEL = DB_ACTV_HI;
    EPwm2Regs.AQCSFRC.bit.CSFA = 1;                 // Forces a continuous low on output A
    EPwm2Regs.AQCSFRC.bit.CSFB = 1;                 // Forces a continuous low on output B
}

//*************************************************************************************************************************
//*************************************************************************************************************************
Uint16 error_check(void){
    Uint16 error;

    error = GpioDataRegs.GPDDAT.bit.GPIO104;

    return error;
}

//*************************************************************************************************************************
//*************************************************************************************************************************
void stop(void){

}
