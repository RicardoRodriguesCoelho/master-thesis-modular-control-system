/*
 * Peripheral_Setup.h
 *
 *  Created on: 23 de jul de 2020
 *      Author: waner
 */

#ifndef PERIPHERAL_SETUP_H_
#define PERIPHERAL_SETUP_H_
#include "F28x_Project.h"

void Setup_GPIO(void);
void Setup_Timer(void);
void Setup_External_Interrupt(void);
void Setup_SPI(void);
void Setup_ePWM(void);
void Setup_ADC(void);
void Setup_DAC(void);

#endif /* PERIPHERAL_SETUP_H_ */
