//###########################################################################
//  FILE:   main.c
//  TITLE:  Master Code
//  CODE:   -
//          -
//
//###########################################################################
//  AUTHOR: Ricardo Coelho
//  DATE: 27_01_2022
//  VERSION: v1.1
//###########################################################################


//****************************************
// Includes
//****************************************
#include "F28x_Project.h"                         //C:\ti\controlSUITE\device_support\F2837xD\v210\F2837xD_common\include
#include "string.h"
#include "stdio.h"
#include "stdlib.h"
#include "math.h"
#include "time.h"
#include "Peripheral_Setup.h"
#include "Function_Definition.h"

//****************************************
// Defines
//****************************************
//#define pi                  3.14159
//#define DOIS_PI_F           314.1592


//****************************************
// Global variables
//****************************************
// Control variables
Uint16 control_state;
Uint16 led_blink_counter;
Uint16 first_case;
Uint16 flag_xint1;
Uint16 flag_xint2;
Uint16 flag_timer0_isr;
Uint16 flag_receive_counter;
Uint16 flag_receive_config;
Uint16 flag_dc_bus;
Uint16 flag_dc_bus_check;
Uint16 user_enable;
Uint16 error;
Uint16 n_slaves;
Uint16 index_pwm;
Uint16 toggle_flag = 1;
Uint16 aux;
Uint16 aux2;
float32 aux_float;

// PLL variables
char start_pll;
float32 pll_uni;
float32 pll_amp;

// PI variables
char start_pi;
float32 amp_current;
float32 pi_ref;
float32 pi_ref2;

// ADC variables
float32 v_grid;
float32 i_grid;
//float32 i_grid2;
float32 v_grid_array[10] = {0};
float32 i_grid_array[10] = {0};
Uint16 average_index;
Uint16 loop;

// SPI variables
Uint16 index;
Uint16 receive_array[50] = {0};
Uint16 flag_receive_array;
Uint16 sdata_a;  // send data
Uint16 sdata_c;  // send data
Uint16 rdata_a;  // received data
Uint16 rdata_c;  // received data


//****************************************
// Prototype statments for functions
//****************************************
void initialize(void);
interrupt void adcaIsr(void);
interrupt void adccIsr(void);
interrupt void xint1_isr(void);
interrupt void xint2_isr(void);
interrupt void xint3_isr(void);
interrupt void timer0_isr(void);
interrupt void spiaRxFifoIsr(void);
interrupt void spicRxFifoIsr(void);


int main(void){

    //
    // Step 1. Initialize System Control:
    //
    // PLL, WatchDog, enable Peripheral Clocks
    // This example function is found in the F2837xD_SysCtrl.c file.
     InitSysCtrl();

    //
    // Step 2. Initialize GPIO:
    //
    // This example function is found in the F2837xD_Gpio.c file and
    // illustrates how to set the GPIO to it's default state.
    // Setup only the GP I/O only for SPI-A functionality
    InitSpiaGpio();

    //
    // Step 3. Initialize PIE vector table:
    //
    // Disable and clear all CPU interrupts
    DINT;
    IER = 0x0000;
    IFR = 0x0000;

    // Initialize PIE control registers to their default state:
    // This function is found in the F2837xD_PieCtrl.c file.
    InitPieCtrl();

    // Initialize the PIE vector table with pointers to the shell Interrupt
    // Service Routines (ISR).
    // This will populate the entire table, even if the interrupt
    // is not used in this example.  This is useful for debug purposes.
    // The shell ISR routines are found in F2837xD_DefaultIsr.c.
    // This function is found in F2837xD_PieVect.c.
    InitPieVectTable();

    // Interrupts that are used in this example are re-mapped to
    // ISR functions found within this file.
    EALLOW;  // This is needed to write to EALLOW protected registers
    CpuSysRegs.PCLKCR0.bit.CPUTIMER0 = 1;       // Enable timer clock

    PieVectTable.ADCA1_INT = &adcaIsr;
    PieVectTable.ADCC1_INT = &adccIsr;
    PieVectTable.XINT1_INT = &xint1_isr;
    PieVectTable.XINT2_INT = &xint2_isr;
    PieVectTable.XINT3_INT = &xint3_isr;
    PieVectTable.TIMER0_INT = &timer0_isr;
    PieVectTable.SPIA_RX_INT = &spiaRxFifoIsr;
    PieVectTable.SPIC_RX_INT = &spicRxFifoIsr;
    EDIS;    // This is needed to disable write to EALLOW protected registers

    //
    // Step 4. Initialize the Device Peripherals:
    //
    Setup_GPIO();
    Setup_Timer();
    Setup_ePWM();
    Setup_SPI();
    Setup_ADC();
    Setup_DAC();
    Setup_External_Interrupt();

    //
    // Step 5. User specific code, enable interrupts:
    //
    // Initialize
    initialize();

    // Enable interrupts required for this example
    PieCtrlRegs.PIECTRL.bit.ENPIE = 1;      // Enable the PIE block

    PieCtrlRegs.PIEIER1.bit.INTx1 = 1;      // Enable PIE Group 1, INT 1  (ADCA1 interrupt)
    PieCtrlRegs.PIEIER1.bit.INTx3 = 1;      // Enable PIE Group 1, INT 3  (ADCC1 interrupt)
    PieCtrlRegs.PIEIER1.bit.INTx4 = 1;      // Enable PIE Group 1, INT 4  (XINT1 interrupt)
    PieCtrlRegs.PIEIER1.bit.INTx5 = 1;      // Enable PIE Group 1, INT 5  (XINT2 interrupt)
    PieCtrlRegs.PIEIER1.bit.INTx7 = 1;      // Enable PIE Group 1, INT 7  (TIMER0 interrupt)
    PieCtrlRegs.PIEIER6.bit.INTx1 = 1;      // Enable PIE Group 6, INT 1  (SPIA_RX interrupt)
    PieCtrlRegs.PIEIER6.bit.INTx9 = 1;      // Enable PIE Group 6, INT 9  (SPIC_RX interrupt)
    PieCtrlRegs.PIEIER12.bit.INTx1 = 1;     // Enable PIE Group 12, INT 1  (XINT3 interrupt)
    IER |= M_INT1;                          // Enable CPU INT1
    IER |= M_INT6;                          // Enable CPU INT6
    IER |= M_INT12;                          // Enable CPU INT12
    EINT;                                   // Enable Global interrupt INTM
    ERTM;                                   // Enable Global realtime interrupt DBGM

    CpuTimer0Regs.TCR.all = 0x4001;         // Start Timer0

    //
    // Step 6. IDLE loop. Just sit and loop forever (optional):
    //
    while(1){
        if(flag_timer0_isr == 1){
            switch(control_state){

            case 0:
                // Initial action
                if(first_case == 0){
                    initialize();
                    first_case = 1;
                }
                // Case action
                if(led_blink_counter > 25000){
                    GpioDataRegs.GPETOGGLE.bit.GPIO139 = 1;
                    GpioDataRegs.GPBTOGGLE.bit.GPIO56 = 1;
                    GpioDataRegs.GPDTOGGLE.bit.GPIO97 = 1;
                    GpioDataRegs.GPCTOGGLE.bit.GPIO94 = 1;
                    GpioDataRegs.GPADAT.bit.GPIO16 =  GpioDataRegs.GPCDAT.bit.GPIO94;
                    led_blink_counter = 0;
                }
                // Condition to switch cases
                if(flag_xint1 ==  1){
                    control_state = 1;
                    first_case = 0;
                    flag_xint1 = 0;
                }
                break;

            case 1:
                // Initial action
                if(first_case == 0){
                    GpioDataRegs.GPESET.bit.GPIO139 = 1;
                    GpioDataRegs.GPBCLEAR.bit.GPIO56 = 1;
                    GpioDataRegs.GPDCLEAR.bit.GPIO97 = 1;
                    GpioDataRegs.GPCCLEAR.bit.GPIO94 = 1;
                    slave_counter();
                    first_case = 1;
                }
                // Condition to switch cases
                if(flag_xint2 ==  1){
                    control_state = 0;
                    first_case = 0;
                    flag_xint2 = 0;

                }
                else if(flag_receive_counter ==  1){
                    control_state = 2;
                    first_case = 0;
                    flag_receive_counter = 0;
                }
                break;

            case 2:
                // Initial action
                if(first_case == 0){
                    GpioDataRegs.GPECLEAR.bit.GPIO139 = 1;
                    GpioDataRegs.GPBSET.bit.GPIO56 = 1;
                    GpioDataRegs.GPDCLEAR.bit.GPIO97 = 1;
                    GpioDataRegs.GPCCLEAR.bit.GPIO94 = 1;
                    slave_config(n_slaves);
                    first_case = 1;
                }
                // Condition to switch cases
                if(flag_xint2 ==  1){
                    control_state = 0;
                    first_case = 0;
                    flag_xint2 = 0;

                }
                else if(flag_receive_config ==  1 && aux == 1){
                    control_state = 3;
                    first_case = 0;
                    flag_receive_config = 0;
                }
                break;

            case 3:
                // Initial action
                if(first_case == 0){
                    GpioDataRegs.GPESET.bit.GPIO139 = 1;
                    GpioDataRegs.GPBSET.bit.GPIO56 = 1;
                    GpioDataRegs.GPDCLEAR.bit.GPIO97 = 1;
                    GpioDataRegs.GPCCLEAR.bit.GPIO94 = 1;
                    slave_dc_bus(n_slaves);
                    first_case = 1;
                }
                // Condition to switch cases
                if(flag_xint2 ==  1){
                    control_state = 0;
                    first_case = 0;
                    flag_xint2 = 0;

                }
                /*else if(flag_dc_bus ==  1){
                    control_state = 4;
                    first_case = 0;
                    flag_dc_bus = 0;
                }*/
                break;

            case 4:
                // Initial action
                if(first_case == 0){
                    GpioDataRegs.GPECLEAR.bit.GPIO139 = 1;
                    GpioDataRegs.GPBCLEAR.bit.GPIO56 = 1;
                    GpioDataRegs.GPDSET.bit.GPIO97 = 1;
                    GpioDataRegs.GPCCLEAR.bit.GPIO94 = 1;
                    GpioDataRegs.GPBCLEAR.bit.GPIO32 = 1;
                    flag_dc_bus_check = dc_bus_check(receive_array, n_slaves);
                    start_pll = 1;
                    first_case = 1;
                }
                // Case action
                /*for(loop = 0; loop < 10; loop++) {
                   v_grid = v_grid + v_grid_array[loop];
                   i_grid = i_grid + i_grid_array[loop];
                }
                v_grid = v_grid / 10;
                i_grid = i_grid / 10;*/
                pll_amp = pll(v_grid, &pll_uni, start_pll);
                DacaRegs.DACVALS.bit.DACVALS = (Uint16)((pll_uni * pll_amp * 4096.0 / 420.0) + 2048.0 - 1.0);
                DacbRegs.DACVALS.bit.DACVALS = (Uint16)((v_grid * 4096.0 / 420.0) + 2048.0 - 1.0);
                // Condition to switch cases
                if(flag_xint2 ==  1){
                    control_state = 0;
                    first_case = 0;
                    flag_xint2 = 0;
                }
                else if(flag_dc_bus_check ==  1 && user_enable == 1 /*&& pll_amp >= 150*/){
                    control_state = 5;
                    first_case = 0;
                    flag_dc_bus = 0;
                }
                break;

            case 5:
                // Initial action
                if(first_case == 0){
                    GpioDataRegs.GPESET.bit.GPIO139 = 1;
                    GpioDataRegs.GPBCLEAR.bit.GPIO56 = 1;
                    GpioDataRegs.GPDSET.bit.GPIO97 = 1;
                    GpioDataRegs.GPCCLEAR.bit.GPIO94 = 1;
                    GpioDataRegs.GPBSET.bit.GPIO32 = 1;
                    start_pll = 1;
                    start_pi = 1;
                    first_case = 1;
                }
                // Case action
                /*for(loop = 0; loop < 10; loop++) {
                   v_grid = v_grid + v_grid_array[loop];
                   i_grid = i_grid + i_grid_array[loop];
                }
                v_grid = v_grid / 10;
                i_grid = i_grid / 10;*/

                pll_amp = pll(v_grid, &pll_uni, start_pll);

                //pi_ref = current_control_pred(v_grid, i_grid, pll_uni, amp_current, start_pi);
                pi_ref = current_control(i_grid, pll_uni, amp_current, start_pi);

                send_pwm_data(((Uint32)pi_ref));
                error = error_check();

                if(amp_current>=1){
                    GpioDataRegs.GPASET.bit.GPIO22 = 1;
                }
                else GpioDataRegs.GPACLEAR.bit.GPIO22 = 1;
                //pi_ref2 = pi_ref/1.23;
                //DacbRegs.DACVALS.bit.DACVALS = (Uint16)pi_ref2;
                //DacbRegs.DACVALS.bit.DACVALS = (Uint16)(aux2 * 2);
                //DacbRegs.DACVALS.bit.DACVALS = (Uint16)((v_grid * 4096.0 / 420.0) + 2048.0 - 1.0);
                DacaRegs.DACVALS.bit.DACVALS = (Uint16)(((pll_uni * amp_current) * 4096.0 / 20.0) + 2048.0 - 1.0);
                DacbRegs.DACVALS.bit.DACVALS = (Uint16)((i_grid * 4096.0 / 20.0) + 2048.0 - 1.0);

                // Condition to switch cases
                /*if (error == 0){
                    control_state = 6;
                    first_case = 0;
                }
                else if (user_enable == 0){
                    control_state = 4;
                    first_case = 0;
                }*/
                if (user_enable == 0){
                                    control_state = 4;
                                    first_case = 0;
                                }
                break;

            case 6:
                // Initial action
                if(first_case == 0){
                    initialize();
                    GpioDataRegs.GPESET.bit.GPIO139 = 1;
                    GpioDataRegs.GPDSET.bit.GPIO97 = 1;
                }
                first_case = 1;
                // Case action
                if(led_blink_counter > 6250){
                    GpioDataRegs.GPETOGGLE.bit.GPIO139 = 1;
                    GpioDataRegs.GPBTOGGLE.bit.GPIO56 = 1;
                    GpioDataRegs.GPDTOGGLE.bit.GPIO97 = 1;
                    GpioDataRegs.GPCTOGGLE.bit.GPIO94 = 1;
                    led_blink_counter = 0;
                }
                // Condition to switch cases
                if(flag_xint2 ==  1){
                    control_state = 0;
                    first_case = 0;
                    flag_xint2 = 0;
                }
                break;

            default:
                break;

            } //end switch(control_state)
            flag_timer0_isr = 0;
        } //end if(flag_timer0_isr == 1)
    } //end while(1)
} //end main()


//************************************************************
// adcaIsr - ISR for ADC-A1
//************************************************************
void initialize(void)
{
    GpioDataRegs.GPECLEAR.bit.GPIO139 = 1;
    GpioDataRegs.GPBCLEAR.bit.GPIO56 = 1;
    GpioDataRegs.GPDCLEAR.bit.GPIO97 = 1;
    GpioDataRegs.GPCCLEAR.bit.GPIO94 = 1;
    GpioDataRegs.GPBCLEAR.bit.GPIO32 = 1;
    // Control variables
    //control_state           = 0;
    led_blink_counter       = 0;
    //first_case              = 0;
    flag_xint1              = 0;
    flag_xint2              = 0;
    flag_timer0_isr         = 0;
    flag_receive_counter    = 0;
    flag_receive_config     = 0;
    flag_dc_bus             = 0;
    flag_dc_bus_check       = 0;
    //user_enable             = 0;
    //error                   = 0;
    n_slaves                = 0;
    aux                     = 0;
    aux_float               = 0.0;
    // PLL variables
    start_pll               = 0;
    pll_uni                 = 0.0;
    pll_amp = pll(v_grid, &pll_uni, start_pll);
    pll_amp                   = 0.0;
    // PI variables
    start_pi                = 0;
    amp_current             = 0.0;
    pi_ref = current_control(i_grid, pll_uni, amp_current, start_pi);
    pi_ref                  = 0.0;
    // ADC variables
    v_grid                  = 0.0;
    i_grid                  = 0.0;
    // SPI variables
    index                   = 0;
    memset(receive_array, 0, sizeof(receive_array));
    flag_receive_array      = 0;
    sdata_a                 = 0;
    sdata_c                 = 0;
    rdata_a                 = 0;
    rdata_c                 = 0;
}


//************************************************************
// adcaIsr - ISR for ADC-A1
//************************************************************
interrupt void adcaIsr(void)
{
    //aux_float = (float32)(-(AdcaResultRegs.ADCRESULT0 - 32768)) * 210 / 32768;      // == AdcaResultRegs.ADCRESULT1 (ADCINA2-ADCINA3)
    //adc1 = (float32)AdcaResultRegs.ADCRESULT2 * 3 / 65536;      // == AdcaResultRegs.ADCRESULT3 (ADCINA4-ADCINA5)
    //adc2 = (float32)AdcaResultRegs.ADCRESULT4 * 3 / 65536;      // == AdcaResultRegs.ADCRESULT5 (ADCINA14-ADCINA15)

    AdcaRegs.ADCINTFLGCLR.bit.ADCINT1 = 1;      //clear INT1 flag
    PieCtrlRegs.PIEACK.all |= PIEACK_GROUP1;
    PieCtrlRegs.PIEACK.all |= PIEACK_GROUP6;
    PieCtrlRegs.PIEACK.all |= PIEACK_GROUP12;
}

//************************************************************
// adccIsr - ISR for ADC-C1
//************************************************************
interrupt void adccIsr(void)
{
    /*v_grid_array[average_index] = (float32)(-(AdccResultRegs.ADCRESULT0 - 32768)) * 420 / 32768;    // == AdccResultRegs.ADCRESULT1 (ADCINC2-ADCINC3)
    i_grid_array[average_index] = (float32)(-(AdccResultRegs.ADCRESULT2 - 32768)) * 17 / 32768;    // == AdccResultRegs.ADCRESULT3 (ADCINC4-ADCINC5)
    average_index++;
    if(average_index >= 10) average_index = 0;
*/
    v_grid = (float32)(-(AdccResultRegs.ADCRESULT0 - 32768)) * 210 / 32768;    // == AdccResultRegs.ADCRESULT1 (ADCINC2-ADCINC3)
    i_grid = (float32)(-(AdccResultRegs.ADCRESULT2 - 32768)) * 53 / 32768;    // == AdccResultRegs.ADCRESULT3 (ADCINC4-ADCINC5)
    i_grid = i_grid/3;

    AdccRegs.ADCINTFLGCLR.bit.ADCINT1 = 1;      //clear INT1 flag
    PieCtrlRegs.PIEACK.all |= PIEACK_GROUP1;
    PieCtrlRegs.PIEACK.all |= PIEACK_GROUP6;
    PieCtrlRegs.PIEACK.all |= PIEACK_GROUP12;
}

//************************************************************
// xint1_isr - External Interrupt 1 ISR
//************************************************************
interrupt void xint1_isr(void)
{
    flag_xint1 = 1;

    // Acknowledge this interrupt to get more from group 1
    PieCtrlRegs.PIEACK.all |= PIEACK_GROUP1;
    PieCtrlRegs.PIEACK.all |= PIEACK_GROUP6;
    PieCtrlRegs.PIEACK.all |= PIEACK_GROUP12;
}

//************************************************************
// xint2_isr - External Interrupt 2 ISR
//************************************************************
interrupt void xint2_isr(void)
{
    flag_xint2 = 1;

    // Acknowledge this interrupt to get more from group 1
    PieCtrlRegs.PIEACK.all |= PIEACK_GROUP1;
    PieCtrlRegs.PIEACK.all |= PIEACK_GROUP6;
    PieCtrlRegs.PIEACK.all |= PIEACK_GROUP12;
}

//************************************************************
// xint3_isr - External Interrupt 3 ISR
//************************************************************
interrupt void xint3_isr(void)
{
    user_enable = GpioDataRegs.GPDDAT.bit.GPIO105;

    // Acknowledge this interrupt to get more from group 1
    PieCtrlRegs.PIEACK.all |= PIEACK_GROUP1;
    PieCtrlRegs.PIEACK.all |= PIEACK_GROUP6;
    PieCtrlRegs.PIEACK.all |= PIEACK_GROUP12;
}

//************************************************************
// timer0_isr - Timer0 ISR
//************************************************************
interrupt void timer0_isr(void)
{
    led_blink_counter++;
    flag_timer0_isr = 1;
    toggle_flag++;

    if(control_state == 5 && toggle_flag == 5) GpioDataRegs.GPATOGGLE.bit.GPIO16 = 1;
    if(toggle_flag > 5) toggle_flag = 1;

    /* Parallel Comunication Test*/
    /*if(control_state == 5 && toggle_flag == 5) GpioDataRegs.GPASET.bit.GPIO16 = 1;
    else GpioDataRegs.GPACLEAR.bit.GPIO16 = 1;
    if(toggle_flag > 5) toggle_flag = 1;*/

    // Acknowledge this interrupt to receive more interrupts from group 1
    PieCtrlRegs.PIEACK.all |= PIEACK_GROUP1;
    PieCtrlRegs.PIEACK.all |= PIEACK_GROUP6;
    PieCtrlRegs.PIEACK.all |= PIEACK_GROUP12;
}

//************************************************************
// spiaRxFifoIsr - ISR for SPI-A receive FIFO
//************************************************************
interrupt void spiaRxFifoIsr(void)
{
    rdata_a=SpiaRegs.SPIRXBUF;          // Read data

    SpiaRegs.SPIFFRX.bit.RXFFOVFCLR=1;  // Clear Overflow flag
    SpiaRegs.SPIFFRX.bit.RXFFINTCLR=1;  // Clear Interrupt flag
    PieCtrlRegs.PIEACK.all |= PIEACK_GROUP1;
    PieCtrlRegs.PIEACK.all |= PIEACK_GROUP6;
    PieCtrlRegs.PIEACK.all |= PIEACK_GROUP12;
}

//************************************************************
// spicRxFifoIsr - ISR for SPI-C receive FIFO
//************************************************************
interrupt void spicRxFifoIsr(void)
{
    rdata_c = SpicRegs.SPIRXBUF;
    receive_array[index] = rdata_c;   // Read data
    index++;

    if(rdata_c == 0x0024){
        if(receive_array[1] == 1){
            flag_receive_counter = 1;
            n_slaves = receive_array[index-2];
        }
        else if(receive_array[1] == 2) flag_receive_config = 1;
        else if (receive_array[1] == 3) flag_dc_bus = 1;

        index = 0;
    }

    SpicRegs.SPIFFRX.bit.RXFFOVFCLR=1;  // Clear Overflow flag
    SpicRegs.SPIFFRX.bit.RXFFINTCLR=1;  // Clear Interrupt flag
    PieCtrlRegs.PIEACK.all |= PIEACK_GROUP1;
    PieCtrlRegs.PIEACK.all |= PIEACK_GROUP6;
    PieCtrlRegs.PIEACK.all |= PIEACK_GROUP12;
}
