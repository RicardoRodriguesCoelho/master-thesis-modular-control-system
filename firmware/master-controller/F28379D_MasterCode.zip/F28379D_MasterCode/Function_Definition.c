/*
 * Function_Definition.c
 *
 *  Created on: 26/05/2022
 *      Author: Ricardo Coelho
 */


//****************************************
// Includes
//****************************************
#include "Function_Definition.h"
#include "math.h"

//****************************************
// Defines
//****************************************
#define DC_Bus_Max          65
#define DC_Bus_Min          55
#define PWM_Period_Max      (5000*0.9)
#define PWM_Period_Min      (5000*0.1)
#define fsampling           50000
#define fsignal             50

#define Pi                  3.14159265
#define w0                  (2 * Pi * fsignal)
#define Ts                  (1.0 / fsampling)
#define kp_p                100
#define ki_p                (50 * (1.0 / fsampling))
#define ki_a                (100 * (1.0 / fsampling))


float32 Kp = 1000;
float32 Ki = 40;
float32 auxL = 0.001;
/*
float32 Kp = 40;
float32 Ki = 3;
*/


//*************************************************************************************************************************
//*************************************************************************************************************************
void slave_counter(void){
    int16 index = 0;
    Uint16 send_array[] = {0x0000, 0x0001, 0x0024};     //{broadcast, count slave, $}

    while (index < 3){
        SpiaRegs.SPITXBUF = send_array[index];
        index++;
        //DELAY_US(1000);
    }
}

//*************************************************************************************************************************
//*************************************************************************************************************************
void slave_config(Uint16 total_slaves){
    int16 index = 0;
    Uint16 phase_delay = 0;
    Uint16 send_array[50]  = {0};

    send_array[0]           = 0x0000;           //{broadcast, config slave, $}
    send_array[1]           = 0x0002;
    send_array[total_slaves+2]  = 0x0024;

    phase_delay = 360 / total_slaves;

    for(index = 0; index < total_slaves; index++){
        send_array[index+2] = phase_delay * index;
    }
    index = 0;

    while (index < total_slaves+3){
        SpiaRegs.SPITXBUF = send_array[index];
        index++;
        //DELAY_US(1000);
    }
}

//*************************************************************************************************************************
//*************************************************************************************************************************
void slave_dc_bus(Uint16 total_slaves){
    int16 index = 0;
    static Uint16 send_array[50] = {0};

    send_array[0]           = 0x0000;           //{broadcast, config slave, $}
    send_array[1]           = 0x0003;
    send_array[total_slaves+2]  = 0x0024;

    while (index < total_slaves+3){
        SpiaRegs.SPITXBUF = send_array[index];
        index++;
        //DELAY_US(1000);
    }
}

//*************************************************************************************************************************
//*************************************************************************************************************************
Uint16 dc_bus_check(Uint16 send_array[], Uint16 total_slaves){
    Uint16 dc_bus_check = 1;
    int16 index = 2;

    while (index < total_slaves+2){
        if(send_array[index] < DC_Bus_Max && send_array[index] > DC_Bus_Min) dc_bus_check &= 1;
        else dc_bus_check &= 0;

        index++;
    }

    return dc_bus_check;
}

//*************************************************************************************************************************
//*************************************************************************************************************************
float32 pll(float32 v_grid, float32 *pll_uni, char start){
    static float32 err, error_a, error_p, sum_a, sum_p, Pi_p, int_p, int_a, pll, _sin, _cos;

    if(start){
        err = v_grid - pll;
        error_a = err * _sin;
        error_p = err * _cos;

        sum_a = sum_a + error_a;
        sum_p = sum_p + error_p;

        Pi_p = kp_p * error_p + ki_p * sum_p + w0;   //definir w0 = 2pif
        int_p = int_p + Pi_p * Ts;                  //definir Ts  1/50k

        if (int_p > 2*Pi)
            int_p = 0;

        if(int_p < -2*Pi)
            int_p = 0;

        _sin = sin(int_p);
        _cos = cos(int_p);

        int_a = sum_a * ki_a;
        pll = _sin * int_a;

        if(!int_a) int_a = 0.00001;

        *(pll_uni) = _sin;
    }
    else{
        sum_a = 0;
        sum_p = 0;
    }
    return int_a;
}

//*************************************************************************************************************************
//*************************************************************************************************************************
float32 current_control(float32 i_grid, float32 pll_uni, float32 amp_current, char start){
    static float32 i_ref, i_error, i_error_sum, pi_ref;

    if(start){
        i_ref = pll_uni * amp_current;
        //i_grid = (float32)(-(AdccResultRegs.ADCRESULT2 - 32768)) * 17 / 32768;
        i_error =  i_ref - i_grid;
        i_error_sum = i_error_sum + i_error;

        if(i_error_sum > 100000) i_error_sum = 100000;
        if(i_error_sum < -100000) i_error_sum = -100000;

        pi_ref = (i_error * Kp) + (i_error_sum * Ki) + 2500;
        if(pi_ref > PWM_Period_Max) pi_ref = PWM_Period_Max;
        else if(pi_ref < PWM_Period_Min) pi_ref = PWM_Period_Min;

    }
    else{
        i_error_sum = 0;
    }
    return pi_ref;
}

//*************************************************************************************************************************
//*************************************************************************************************************************
float32 current_control_pred(float32 v_grid, float32 i_grid, float32 pll_uni, float32 amp_current, char start){
    static float32 i_ref, i_ref_ant, pi_ref;

    i_ref = pll_uni * amp_current;
    pi_ref = (v_grid+auxL*fsampling*(2*i_ref-i_ref_ant-i_grid))*(2500.0/(34.0*3.0-9.0))+2500;
    i_ref_ant = i_ref;

    return pi_ref;
}
//*************************************************************************************************************************
//*************************************************************************************************************************
void send_pwm_data(Uint32 pi_ref){
    Uint32 first_aux, second_aux, third_aux;
    Uint32 previous_clock;

    previous_clock = ((Uint32)GpioDataRegs.GPADAT.bit.GPIO16)<<16;

    if(pi_ref >= PWM_Period_Max) pi_ref = PWM_Period_Max;
    if(pi_ref <= PWM_Period_Min) pi_ref = PWM_Period_Min;

    pi_ref = pi_ref>>1;

    first_aux = ((pi_ref<<4) & 0x00000FF0);
    second_aux = ((pi_ref<<16) & 0x0F000000);
    third_aux = first_aux | second_aux;
    third_aux = third_aux | previous_clock;

    GpioDataRegs.GPADAT.all = third_aux;
}

//*************************************************************************************************************************
//*************************************************************************************************************************
Uint16 error_check(void){
    Uint16 error;

    error = GpioDataRegs.GPDDAT.bit.GPIO104;

    return error;
}

//*************************************************************************************************************************
//*************************************************************************************************************************
void stop(void){

}
