/*
 * Peripheral_Setup.c
 *
 *  Created on: 23 de jul de 2020
 *      Author: waner
 */

#include "Peripheral_Setup.h"

//************************************************************************************************************************
//*************************************************************************************************************************
void Setup_GPIO(void)
{
    EALLOW;

    // ********    GPIO_COM     ******** //
    GpioCtrlRegs.GPAMUX1.all  = 0X0000;
    GpioCtrlRegs.GPAMUX2.all  = 0X0000;
    GpioCtrlRegs.GPADIR.all   = 0xFFFFFFFF; //1: Configures pin as output.
    GpioCtrlRegs.GPACSEL1.all = GPIO_MUX_CPU1;    //GPIO is controlled by CPU1
    GpioCtrlRegs.GPACSEL2.all = GPIO_MUX_CPU1;    //GPIO is controlled by CPU1

    // **********    SPI     ********** //
    // *** SPI-A *** //
    // Enable internal pull-up for the selected pins
    GpioCtrlRegs.GPBPUD.bit.GPIO58 = 0;     // Enable pull-up on GPIO58 (SPISIMOA)
    GpioCtrlRegs.GPBPUD.bit.GPIO59 = 0;     // Enable pull-up on GPIO59(SPISOMIA)
    GpioCtrlRegs.GPBPUD.bit.GPIO60 = 0;     // Enable pull-up on GPIO60 (SPICLKA)
    GpioCtrlRegs.GPBPUD.bit.GPIO61 = 0;     // Enable pull-up on GPIO61 (SPISTEA)
    // Set qualification for selected pins to asynch only
    GpioCtrlRegs.GPBQSEL2.bit.GPIO58 = 3;   // Asynch input GPIO58 (SPISIMOA)
    GpioCtrlRegs.GPBQSEL2.bit.GPIO59 = 3;   // Asynch input GPIO59 (SPISOMIA)
    GpioCtrlRegs.GPBQSEL2.bit.GPIO60 = 3;   // Asynch input GPIO60 (SPICLKA)
    GpioCtrlRegs.GPBQSEL2.bit.GPIO61 = 3;   // Asynch input GPIO61 (SPISTEA)
    // Configure SPI-A pins using GPIO regs
    GpioCtrlRegs.GPBMUX2.bit.GPIO58  = 3;    // Configure GPIO58 as SPISIMOA
    GpioCtrlRegs.GPBMUX2.bit.GPIO59  = 3;    // Configure GPIO59 as SPISOMIA
    GpioCtrlRegs.GPBMUX2.bit.GPIO60  = 3;    // Configure GPIO60 as SPICLKA
    GpioCtrlRegs.GPBMUX2.bit.GPIO61  = 3;    // Configure GPIO61 as SPISTEA
    GpioCtrlRegs.GPBGMUX2.bit.GPIO58 = 3;    // Configure GPIO58 as SPISIMOA
    GpioCtrlRegs.GPBGMUX2.bit.GPIO59 = 3;    // Configure GPIO59 as SPISOMIA
    GpioCtrlRegs.GPBGMUX2.bit.GPIO60 = 3;    // Configure GPIO60 as SPICLKA
    GpioCtrlRegs.GPBGMUX2.bit.GPIO61 = 3;    // Configure GPIO61 as SPISTEA

    // *** SPI-C *** //
    // Enable internal pull-up for the selected pins
    GpioCtrlRegs.GPDPUD.bit.GPIO122 = 0;     // Enable pull-up on GPIO122 (SPISIMOC)
    GpioCtrlRegs.GPDPUD.bit.GPIO123 = 0;     // Enable pull-up on GPIO123 (SPISOMIC)
    GpioCtrlRegs.GPDPUD.bit.GPIO124 = 0;     // Enable pull-up on GPIO124 (SPICLKC)
    GpioCtrlRegs.GPDPUD.bit.GPIO125 = 0;     // Enable pull-up on GPIO125 (SPISTEC)
    // Set qualification for selected pins to asynch only
    GpioCtrlRegs.GPDQSEL2.bit.GPIO122 = 3;   // Asynch input GPIO122 (SPISIMOC)
    GpioCtrlRegs.GPDQSEL2.bit.GPIO123 = 3;   // Asynch input GPIO123 (SPISOMIC)
    GpioCtrlRegs.GPDQSEL2.bit.GPIO124 = 3;   // Asynch input GPIO124 (SPICLKC)
    GpioCtrlRegs.GPDQSEL2.bit.GPIO125 = 3;   // Asynch input GPIO125 (SPISTEC)
    // Configure SPI-C pins using GPIO regs
    GpioCtrlRegs.GPDMUX2.bit.GPIO122  = 2;   // Configure GPIO122 as SPISIMOC
    GpioCtrlRegs.GPDMUX2.bit.GPIO123  = 2;   // Configure GPIO123 as SPISOMIC
    GpioCtrlRegs.GPDMUX2.bit.GPIO124  = 2;   // Configure GPIO124 as SPICLKC
    GpioCtrlRegs.GPDMUX2.bit.GPIO125  = 2;   // Configure GPIO125 as SPISTEC
    GpioCtrlRegs.GPDGMUX2.bit.GPIO122 = 1;   // Configure GPIO122 as SPISIMOC
    GpioCtrlRegs.GPDGMUX2.bit.GPIO123 = 1;   // Configure GPIO123 as SPISOMIC
    GpioCtrlRegs.GPDGMUX2.bit.GPIO124 = 1;   // Configure GPIO124 as SPICLKC
    GpioCtrlRegs.GPDGMUX2.bit.GPIO125 = 1;   // Configure GPIO125 as SPISTEC

    // ********    GPIOs     ******** //
    // Enable DSC (output)
    GpioCtrlRegs.GPBMUX1.bit.GPIO32  = 0;
    GpioCtrlRegs.GPBDIR.bit.GPIO32   = 1;
    GpioCtrlRegs.GPBCSEL1.bit.GPIO32 = GPIO_MUX_CPU1;    //GPIO1 is controlled by CPU1
    // LED - State 0 (output)
    GpioCtrlRegs.GPEMUX1.bit.GPIO139  = 0;
    GpioCtrlRegs.GPEDIR.bit.GPIO139   = 1;
    GpioCtrlRegs.GPECSEL2.bit.GPIO139 = GPIO_MUX_CPU1;    //GPIO1 is controlled by CPU1
    // LED - State 1 (output)
    GpioCtrlRegs.GPBMUX2.bit.GPIO56  = 0;
    GpioCtrlRegs.GPBDIR.bit.GPIO56   = 1;
    GpioCtrlRegs.GPBQSEL2.bit.GPIO56 = GPIO_MUX_CPU1;    //GPIO1 is controlled by CPU1
    // LED - State 2 (output)
    GpioCtrlRegs.GPDMUX1.bit.GPIO97  = 0;
    GpioCtrlRegs.GPDDIR.bit.GPIO97   = 1;
    GpioCtrlRegs.GPDCSEL1.bit.GPIO97 = GPIO_MUX_CPU1;    //GPIO1 is controlled by CPU1
    // LED - State 3 (output)
    GpioCtrlRegs.GPCMUX2.bit.GPIO94  = 0;
    GpioCtrlRegs.GPCDIR.bit.GPIO94   = 1;
    GpioCtrlRegs.GPCQSEL2.bit.GPIO94 = GPIO_MUX_CPU1;    //GPIO1 is controlled by CPU1
    // Button - S1 (input)
    GpioCtrlRegs.GPBMUX1.bit.GPIO41  = 0;
    GpioCtrlRegs.GPBDIR.bit.GPIO41   = 0;
    GpioCtrlRegs.GPBCSEL2.bit.GPIO41 = GPIO_MUX_CPU1;    //GPIO1 is controlled by CPU1
    // Button - S2 (input)
    GpioCtrlRegs.GPBMUX1.bit.GPIO40  = 0;
    GpioCtrlRegs.GPBDIR.bit.GPIO40   = 0;
    GpioCtrlRegs.GPBCSEL2.bit.GPIO40 = GPIO_MUX_CPU1;    //GPIO1 is controlled by CPU1
    // User Enable (input)
    GpioCtrlRegs.GPDMUX1.bit.GPIO105    = 0;
    GpioCtrlRegs.GPDDIR.bit.GPIO105     = 0;
    GpioCtrlRegs.GPDCSEL2.bit.GPIO105   = GPIO_MUX_CPU1;    //GPIO1 is controlled by CPU1
    // Error (input)
    GpioCtrlRegs.GPDMUX1.bit.GPIO104    = 0;
    GpioCtrlRegs.GPDDIR.bit.GPIO104     = 0;
    GpioCtrlRegs.GPDCSEL2.bit.GPIO104   = GPIO_MUX_CPU1;    //GPIO1 is controlled by CPU1
    EDIS;
    //EXtra (output)
    GpioCtrlRegs.GPAMUX2.bit.GPIO22  = 0;
    GpioCtrlRegs.GPADIR.bit.GPIO22   = 1;
    GpioCtrlRegs.GPACSEL3.bit.GPIO22 = GPIO_MUX_CPU1;
}

//************************************************************************************************************************
//************************************************************************************************************************
void Setup_Timer(void)
{
    // *** Timer 0 *** //
    InitCpuTimers();
    ConfigCpuTimer(&CpuTimer0, 200, 20); // ConfigCpuTimer(struct CPUTIMER_VARS *Timer, float Freq, float Period)

}

//************************************************************************************************************************
//************************************************************************************************************************
void Setup_External_Interrupt(void)
{
    GPIO_SetupXINT1Gpio(41);
    GPIO_SetupXINT2Gpio(40);
    GPIO_SetupXINT3Gpio(105);

    EALLOW;
    // Configure XINTx                      // 0 = Falling edge interrupt; 1 = Rising edge interrupt; 3 = Rising and Fallind edge interrupt
    XintRegs.XINT1CR.bit.POLARITY = 0;      // 0 = Falling edge interrupt
    XintRegs.XINT2CR.bit.POLARITY = 0;      // 0 = Falling edge interrupt
    XintRegs.XINT3CR.bit.POLARITY = 3;      // 3 = Rising and Fallind edge interrupt
    // Enable XINTx
    XintRegs.XINT1CR.bit.ENABLE = 1;        // Enable XINT1
    XintRegs.XINT2CR.bit.ENABLE = 1;        // Enable XINT2
    XintRegs.XINT3CR.bit.ENABLE = 1;        // Enable XINT3

    EDIS;
}

//************************************************************************************************************************
//************************************************************************************************************************
void Setup_SPI()
{
    EALLOW;

    // ********    SPI-A    ******** //
    // Initialize SPI FIFO registers
    SpiaRegs.SPIFFTX.all = 0xE040;
    SpiaRegs.SPIFFRX.all = 0x2061;
    SpiaRegs.SPIFFCT.all = 0x0000;
    // Set reset low before configuration changes
    // Clock polarity (0 == rising, 1 == falling)
    // 16-bit character
    // Enable loop-back
    SpiaRegs.SPICCR.bit.SPISWRESET  = 0;
    SpiaRegs.SPICCR.bit.CLKPOLARITY = 0;
    SpiaRegs.SPICCR.bit.SPICHAR     = (16 - 1);
    SpiaRegs.SPICCR.bit.SPILBK      = 0;
    // Enable master (0 == slave, 1 == master)
    // Enable transmission (Talk)
    // Clock phase (0 == normal, 1 == delayed)
    // SPI interrupts are disabled
    SpiaRegs.SPICTL.bit.MASTER_SLAVE = 1;
    SpiaRegs.SPICTL.bit.TALK         = 1;
    SpiaRegs.SPICTL.bit.CLK_PHASE    = 0;
    SpiaRegs.SPICTL.bit.SPIINTENA    = 1;
    // Set the baud rate
    SpiaRegs.SPIBRR.bit.SPI_BIT_RATE = ((200E6 / 4) / 500E3) - 1;
    // Set FREE bit
    // Halting on a breakpoint will not halt the SPI
    SpiaRegs.SPIPRI.bit.FREE = 1;
    // Release the SPI from reset
    SpiaRegs.SPICCR.bit.SPISWRESET = 1;

    // ********    SPI-C    ******** //
    // Initialize SPI FIFO registers
    SpicRegs.SPIFFTX.all = 0xE040;
    SpicRegs.SPIFFRX.all = 0x2061;
    SpicRegs.SPIFFCT.all = 0x0000;
    // Set reset low before configuration changes
    // Clock polarity (0 == rising, 1 == falling)
    // 16-bit character
    // Enable loop-back
    SpicRegs.SPICCR.bit.SPISWRESET  = 0;
    SpicRegs.SPICCR.bit.CLKPOLARITY = 0;
    SpicRegs.SPICCR.bit.SPICHAR     = (16 - 1);
    SpicRegs.SPICCR.bit.SPILBK      = 0;
    // Enable master (0 == slave, 1 == master)
    // Enable transmission (Talk)
    // Clock phase (0 == normal, 1 == delayed)
    // SPI interrupts are disabled
    SpicRegs.SPICTL.bit.MASTER_SLAVE = 0;
    SpicRegs.SPICTL.bit.TALK         = 1;
    SpicRegs.SPICTL.bit.CLK_PHASE    = 0;
    SpicRegs.SPICTL.bit.SPIINTENA    = 1;
    // Set the baud rate
    // Calculate BRR: 7-bit baud rate register value
    // SPI CLK freq = 500 kHz
    // LSPCLK freq  = CPU freq / 4  (by default)
    // BRR          = (LSPCLK freq / SPI CLK freq) - 1
    SpicRegs.SPIBRR.bit.SPI_BIT_RATE = ((200E6 / 4) / 500E3) - 1;
    // Set FREE bit
    // Halting on a breakpoint will not halt the SPI
    SpicRegs.SPIPRI.bit.FREE = 1;
    // Release the SPI from reset
    SpicRegs.SPICCR.bit.SPISWRESET = 1;

    EDIS;
}

//************************************************************************************************************************
//************************************************************************************************************************
void Setup_ePWM(void)
{

    EALLOW;
    CpuSysRegs.PCLKCR0.bit.TBCLKSYNC = 0;
    CpuSysRegs.PCLKCR2.bit.EPWM8 = 1;

    // ********    PWM-8     ******** //
    EPwm8Regs.TBPRD = 2500;                         // Set timer period (((100Mhz/CLKDIV)/Fpwm)/2)
    EPwm8Regs.CMPA.bit.CMPA = 1250;                 // Setup compare
    EPwm8Regs.TBPHS.bit.TBPHS = 0;                  // Phase is 0
    EPwm8Regs.TBCTR = 0x0000;                       // Clear counter
    EPwm8Regs.TBCTL.bit.SYNCOSEL = TB_CTR_ZERO;     // Sync down-stream module
    EPwm8Regs.TBCTL.bit.CTRMODE = TB_COUNT_UPDOWN;  // Count up/down
    EPwm8Regs.TBCTL.bit.PHSEN = TB_DISABLE;         // Disable phase loading
    EPwm8Regs.TBCTL.bit.HSPCLKDIV = TB_DIV1;        // Clock ratio to SYSCLKOUT
    EPwm8Regs.TBCTL.bit.CLKDIV = TB_DIV2;
    EPwm8Regs.TBCTL.bit.PRDLD = TB_SHADOW;          // Period autoreload
    EPwm8Regs.CMPCTL.bit.SHDWAMODE = CC_SHADOW;     // Load registers every ZERO
    EPwm8Regs.CMPCTL.bit.LOADAMODE = CC_CTR_ZERO_PRD;
    EPwm8Regs.CMPCTL.bit.SHDWBMODE = CC_SHADOW;     // Load registers every ZERO
    EPwm8Regs.CMPCTL.bit.LOADBMODE = CC_CTR_ZERO_PRD;
    // Set actions
    EPwm8Regs.AQCTLA.bit.CAU = AQ_SET;
    EPwm8Regs.AQCTLA.bit.CAD = AQ_CLEAR;
    EPwm8Regs.AQCTLB.bit.CAU = AQ_CLEAR;
    EPwm8Regs.AQCTLB.bit.CAD = AQ_SET;
    // Dead time config
    EPwm8Regs.DBCTL.bit.OUT_MODE = DB_FULL_ENABLE;  // Enable Dead-band module
    EPwm8Regs.DBCTL.bit.POLSEL = DB_ACTV_HIC;       // Active High complementary
    EPwm8Regs.DBRED.all = 100;                      // Set 100 clock ticks of rising edge dead time ( x us)
    EPwm8Regs.DBFED.all = 100;                      // Set 100 clock ticks of falling edge dead time ( x us)
    CpuSysRegs.PCLKCR0.bit.TBCLKSYNC = 1;
    // Stop PWM
    EPwm8Regs.DBCTL.bit.POLSEL = DB_ACTV_HI;
    EPwm8Regs.AQCSFRC.bit.CSFA = 1;                 // Forces a continuous low on output A
    EPwm8Regs.AQCSFRC.bit.CSFB = 1;                 // Forces a continuous low on output B

    CpuSysRegs.PCLKCR0.bit.TBCLKSYNC = 1;
    EDIS;
}

//************************************************************************************************************************
//************************************************************************************************************************
void Setup_ADC(void)
{
    Uint16 acqps;

    EALLOW;
    CpuSysRegs.PCLKCR13.bit.ADC_A = 1;
    CpuSysRegs.PCLKCR13.bit.ADC_C = 1;

    // ********    ADC-A    ******** //
    AdcaRegs.ADCCTL2.bit.PRESCALE = 6;          // set ADCCLK divider to /4
    AdcSetMode(ADC_ADCA, ADC_RESOLUTION_16BIT, ADC_SIGNALMODE_DIFFERENTIAL);
    AdcaRegs.ADCCTL1.bit.INTPULSEPOS = 1;       // Set pulse um ciclo antes do resultado
    AdcaRegs.ADCCTL1.bit.ADCPWDNZ = 1;          // power up the ADC
    DELAY_US(1000);                             // delay for 1ms to allow ADC time to power up
    // Determine minimum acquisition window (in SYSCLKS) based on resolution
    if(ADC_RESOLUTION_12BIT == AdcaRegs.ADCCTL2.bit.RESOLUTION)
        acqps = 14;                             // 75ns
    else                                        // resolution is 16-bit
        acqps = 63;
    // SOC0 Config
    AdcaRegs.ADCSOC0CTL.bit.CHSEL = 2;
    AdcaRegs.ADCSOC0CTL.bit.ACQPS = acqps;      //sample window is 15 SYSCLK cycles
    AdcaRegs.ADCSOC0CTL.bit.TRIGSEL = 0x01;     //trigger on ePWM7 SOCA
    // SOC1 Config
    AdcaRegs.ADCSOC1CTL.bit.CHSEL = 3;
    AdcaRegs.ADCSOC1CTL.bit.ACQPS = acqps;      //sample window is 15 SYSCLK cycles
    AdcaRegs.ADCSOC1CTL.bit.TRIGSEL = 0x01;     //trigger on ePWM7 SOCA
    //ADC Interrupt 1 and 2 Selection Register
    AdcaRegs.ADCINTSEL1N2.bit.INT1SEL = 1;      // end of SOC1 will set INT1 flag
    AdcaRegs.ADCINTSEL1N2.bit.INT1E = 1;        // enable INT1 flag
    AdcaRegs.ADCINTFLGCLR.bit.ADCINT1 = 1;      // make sure INT1 flag is cleared

    // ********    ADC-C    ******** //
    AdccRegs.ADCCTL2.bit.PRESCALE = 6;          // set ADCCLK divider to /4
    AdcSetMode(ADC_ADCC, ADC_RESOLUTION_16BIT, ADC_SIGNALMODE_DIFFERENTIAL);
    AdccRegs.ADCCTL1.bit.INTPULSEPOS = 1;       // Set pulse um ciclo antes do resultado
    AdccRegs.ADCCTL1.bit.ADCPWDNZ = 1;          // power up the ADC
    DELAY_US(1000);                             // delay for 1ms to allow ADC time to power up
    // Determine minimum acquisition window (in SYSCLKS) based on resolution
    if(ADC_RESOLUTION_12BIT == AdccRegs.ADCCTL2.bit.RESOLUTION)
        acqps = 14;                             // 75ns
    else                                        // resolution is 16-bit
        acqps = 63;
    // 320ns
    // SOC0 Config
    AdccRegs.ADCSOC0CTL.bit.CHSEL = 2;
    AdccRegs.ADCSOC0CTL.bit.ACQPS = acqps;      //sample window is 15 SYSCLK cycles
    AdccRegs.ADCSOC0CTL.bit.TRIGSEL = 0x01;     //trigger on ePWM7 SOCA
    // SOC1 Config
    AdccRegs.ADCSOC1CTL.bit.CHSEL = 3;
    AdccRegs.ADCSOC1CTL.bit.ACQPS = acqps;      //sample window is 15 SYSCLK cycles
    AdccRegs.ADCSOC1CTL.bit.TRIGSEL = 0x01;     //trigger on ePWM7 SOCA
    // SOC2 Config
    AdccRegs.ADCSOC2CTL.bit.CHSEL = 4;
    AdccRegs.ADCSOC2CTL.bit.ACQPS = acqps;      //sample window is 15 SYSCLK cycles
    AdccRegs.ADCSOC2CTL.bit.TRIGSEL = 0x01;     //trigger on ePWM7 SOCA
    // SOC3 Config
    AdccRegs.ADCSOC3CTL.bit.CHSEL = 5;
    AdccRegs.ADCSOC3CTL.bit.ACQPS = acqps;      //sample window is 15 SYSCLK cycles
    AdccRegs.ADCSOC3CTL.bit.TRIGSEL = 0x01;     //trigger on ePWM7 SOCA
    //ADC Interrupt 1 and 2 Selection Register
    AdccRegs.ADCINTSEL1N2.bit.INT1SEL = 3;      // end of SOC1 will set INT1 flag
    AdccRegs.ADCINTSEL1N2.bit.INT1E = 1;        // enable INT1 flag
    AdccRegs.ADCINTFLGCLR.bit.ADCINT1 = 1;      // make sure INT1 flag is cleared

    EDIS;
}

//************************************************************************************************************************
//************************************************************************************************************************
void Setup_DAC(void)
{
    EALLOW;
    CpuSysRegs.PCLKCR16.bit.DAC_A = 1;
    CpuSysRegs.PCLKCR16.bit.DAC_B = 1;

    // ********    DAC-A    ******** //
    DacaRegs.DACCTL.bit.SYNCSEL =       0x06;   // EPWM7SYNCPER signal will update the DACVALA register
    DacaRegs.DACCTL.bit.LOADMODE =      0x01;   // Load on next EPWMSYNCPER specified by SYNCSEL
    DacaRegs.DACCTL.bit.DACREFSEL =     0x01;   // ADC VREFHI/VSSA are the reference voltages
    DacaRegs.DACVALS.bit.DACVALS =      0;
    DacaRegs.DACOUTEN.bit.DACOUTEN =    1;      // DAC output is enabled
    DacaRegs.DACLOCK.all =              0x00;

    // ********    DAC-B    ******** //
    DacbRegs.DACCTL.bit.SYNCSEL =       0x06;   // EPWM7SYNCPER signal will update the DACVALA register
    DacbRegs.DACCTL.bit.LOADMODE =      0x01;   // Load on next EPWMSYNCPER specified by SYNCSEL
    DacbRegs.DACCTL.bit.DACREFSEL =     0x01;   // ADC VREFHI/VSSA are the reference voltages
    DacbRegs.DACVALS.bit.DACVALS =      0;
    DacbRegs.DACOUTEN.bit.DACOUTEN =    1;      // DAC output is enabled
    DacbRegs.DACLOCK.all =              0x00;

    EDIS;
}

