/*
 * Function_Definition.h
 *
 *  Created on: 26/05/2022
 *      Author: Ricardo Coelho
 */

#ifndef FUNCTION_DEFINITION_H_
#define FUNCTION_DEFINITION_H_
#include "F28x_Project.h"

void slave_counter(void);
void slave_config(Uint16 total_slaves);
void slave_dc_bus(Uint16 total_slaves);
Uint16 dc_bus_check(Uint16 send_array[], Uint16 total_slaves);
float32 pll(float32 v_grid, float32 * pll_uni, char start);
float32 current_control(float32 i_grid, float32 pll_uni, float32 amp_current, char start);
float32 current_control_pred(float32 v_grid, float32 i_grid, float32 pll_uni, float32 amp_current, char start);
void send_pwm_data(Uint32 pi_ref);
Uint16 error_check(void);
void stop(void);

#endif /* FUNCTION_DEFINITION_H_ */
